(* (C)        Jean-Fran�ois Monin, 1999            *)
(* Centre National d'Etudes des T�l�communications *)
(* $Id: perf.ml,v 1.3 1999/04/01 09:51:04 monin Exp $ *)

module Ord_int =
  struct
    type t = int
    let compare x y = x - y
  end

module S = Splay.Make(Ord_int)
module S_ = Hashtbl

let t = S.create ()

let arg n = int_of_string Sys.argv.(n)
let rate = arg 1  (* rate/10 add and 9*rate/10 find *)
let width = arg 2 (* nb of items accessed *)
let size = arg 3  (* size of the tbl *)
let nbacc = arg 4 (* number of access *)

let _ = Random.init 1515

let often =
  let often = Array.create width 0 in
  for i = 0 to width - 1 do often.(i) <- Random.int size done;
  often

let init () =
  for i = 0 to size do S.add t i () done

let add () =
  let i = Random.int size in
  if S.mem t i then () else S.add t i ()
let find () = let _ = S.mem t often.(Random.int width) in ()

let access () =
  for i = 1 to nbacc do
    if Random.int 10 < rate then add () else find ()
  done

let _ = Chrono.chrono access ()
