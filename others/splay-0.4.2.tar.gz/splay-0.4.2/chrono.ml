let chrono f x = 
  let tm0 =  Unix.gettimeofday () in 
  let ptm0 = Unix.times () in f x; 
  let tm1 =  Unix.gettimeofday () in 
  let ptm1 = Unix.times () in
  Printf.printf "total = %f s ; cpu = %f s ; sys = %f s\n"
    (tm1 -. tm0)
    (ptm1.Unix.tms_utime -. ptm0.Unix.tms_utime)
    (ptm1.Unix.tms_stime -. ptm0.Unix.tms_stime)
