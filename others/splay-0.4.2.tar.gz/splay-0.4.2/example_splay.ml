(* (C)        Jean-Fran�ois Monin, 1999            *)
(* Centre National d'Etudes des T�l�communications *)
(* $Id: example_splay.ml,v 1.9 1999/04/12 08:40:07 monin Exp $ *)
module Ord_int =
  struct
    type t = int
    let compare x y = x - y
  end

module S = Splay.Make(Ord_int)

let t = S.create ()

let see t = S.print print_int print_string t

let b0 = let b = S.mem t 1 in see t; b
let e1 = S.is_empty t
let c1 = S.cardinal t
let _ = S.add t 1 "un"; S.add t 3 "trois"; S.add t 2 "deux"; see t
let b1 = let b = S.mem t 1 in see t; b
let _ = S.set t 3 "3"; see t
let c2 = S.cardinal t
let _ = S.clear t; see t
let _ = S.add t 1 "un"; S.add t 3 "trois"; S.add t 2 "deux"
let _ = S.add t 5 "cinq"; S.add t 9 "neuf"; S.add t 7 "sept"; see t
let e2 = S.is_empty t
let f2 = let f = S.find t 2 in see t; f
let _ = try S.remove t 4 with Not_found -> Printf.printf "4 not there\n"
let c3 = S.cardinal t
let _ = S.remove t 1; see t
let _ = S.iter (fun n s -> Printf.printf "%d = %s\n" n s) t
let l = S.to_list t
let _ = List.iter (fun (n,s) -> Printf.printf "%d*%s; " n s) l; print_newline ()
let mi,smi = S.min_elt t
let ma,sma = S.max_elt t
let _ = Printf.printf "mi = %d; ma = %d\n" mi ma
let  _ =
  try S.add t 3 "three" 
  with S.Already_there -> Printf.printf "3 already there\n"

let t1 = S.copy t
let _ = S.remove t 3; see t; see t1
let t = S.copy t1

let fsix,_ = let nd = S.floor t 6 in see t; nd
let csept,_ = let nd = S.ceil t 7 in see t; nd
let _ = Printf.printf "floor 6 = %d; ceil 7 = %d\n" fsix csept

let nd,_ = let nd = S.next t 2 in see t; nd
let _ = try let _ = S.next t 9 in () with Not_found -> Printf.printf "no 9.next\n"; see t
let ps,_ = let nd = S.prev t 7 in see t; nd
let _ = Printf.printf "next 2 = %d; prev 7 = %d\n" nd ps

let st = S.sub t 4 5
let _ = see st; see t

let st = S.sub t 3 10
let _ = see st; see t

let st = S.sub t 2 6
let _ = see st; see t

let ft = S.filter (fun c v -> c mod 3 = 0) t
let _ = see ft; see t

let mt = S.map (fun c v -> string_of_int (c mod 3)) t
let _ = see mt; see t

let st = S.to_stream t
let _ = Stream.iter (fun (n,s) -> Printf.printf "%d*%s; " n s) st; print_newline ()

let sf = S.from t 6
let _ = see sf; see t
